import { Component } from '@angular/core';

@Component({
  selector: 'app-rubro',
  standalone: true,
  imports: [],
  templateUrl: './rubro.component.html',
  styleUrl: './rubro.component.scss'
})
export class RubroComponent {

}
